# Berikan 2 ke variable apple_price 
apple_price = 2

# Berikan 5 ke variable count 
count = 5

# Berikan hasil dari apple_price * count ke variable total_price 
total_price = apple_price * count


# Dengan menggunakan variable count, cetak 'Anda akan membeli .. apel'
print('Anda akan membeli ' + str(count) + ' apel')

# Dengan menggunakan variable total_price, cetak 'Harga total adalah .. dolar'
print('Harga total adalah ' + str(total_price) + ' dolar')